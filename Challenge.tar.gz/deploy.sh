#!/bin/sh 

cd ~ 
#tar -zxf ~/Kaltura_Challenge.tar.gz
cd ~/prometheus-grafana
echo '******* Install Prometheus' 
sudo ./1-install.sh 
echo '******* Install Grafana' 
sudo ./3-install-grafana.sh

echo '******* Install Graphite' 
cd ~/graphite
sudo ./install-graphite.sh

MY_IP=$(curl -s ipinfo.io/ip)
echo
echo "Connect to Prometheus web interface via:  http://$MY_IP:9090 "
echo
echo "Connect to Grafana web interface via:  http://$MY_IP:3000. Use admin/admin for initial login"
echo
echo "Connect to Graphite web interface via:  http://$MY_IP " 
echo
