#!/bin/sh 

# 
# Source: https://packagecloud.io/go-graphite/stable/install#manual
#

# Step 1. Setup the repo 
sudo apt-get update
sudo apt-get install debian-archive-keyring
sudo apt-get install curl gnupg apt-transport-https
curl -L https://packagecloud.io/go-graphite/stable/gpgkey | sudo apt-key add -
echo 'deb https://packagecloud.io/go-graphite/stable/ubuntu/ trusty main' > /etc/apt/sources.list.d/go-graphite_stable.list
echo 'deb-src https://packagecloud.io/go-graphite/stable/ubuntu/ trusty main' >> /etc/apt/sources.list.d/go-graphite_stable.list
sudo apt-get update

# 
# Source: https://www.vultr.com/docs/how-to-install-and-configure-graphite-on-ubuntu-16-04 
# 

mkdir -p ~/graphite
cd ~/graphite

# Step 2: Install Graphite
sudo apt-get install graphite-web graphite-carbon -y 

# Step 3: Install and configure PostgreSQL
sudo apt-get install postgresql libpq-dev python-psycopg2 -y

# create a PostgreSQL user and database for Graphite to use
echo 
echo '********** Create PostgreSQL user "grahpite" and database for Graphite "graphite" to use *********' 
echo '********** PostgreSQL user "graphite is set to "password" *********' 
echo 
sleep 2 
sudo -u postgres psql -f ~/graphite/crt_postgres_user_db.sql

# Step 4: Configure Graphite
echo '********** In the next step, You will be asked to create a superuser account for the database as shown in the following output: ' 
echo '********** For the sake of this demo, set the password to "password"' 
echo 
sleep 2 
sudo cp local_settings.py /etc/graphite/local_settings.py 
sudo graphite-manage migrate auth
sudo graphite-manage syncdb

# Step 5: Configure Carbon
sudo cp ~/graphite/graphite-carbon /etc/default/graphite-carbon 
sudo cp ~/graphite/carbon.conf /etc/carbon/carbon.conf
sudo cp ~/graphite/storage-schemas.conf /etc/carbon/storage-schemas.conf 
sudo cp /usr/share/doc/graphite-carbon/examples/storage-aggregation.conf.example /etc/carbon/storage-aggregation.conf

sudo systemctl restart carbon-cache 

# Install & Configure Apache for Graphite
sudo apt-get install apache2 libapache2-mod-wsgi -y
sudo cp /usr/share/graphite-web/apache2-graphite.conf /etc/apache2/sites-available/
sudo a2dissite 000-default
sudo systemctl reload apache2 
sudo a2ensite apache2-graphite
sudo systemctl reload apache2 
sudo systemctl restart apache2

MY_IP=$(curl -s ipinfo.io/ip) 
echo 
echo "Connect to http://$MY_IP to see Graphite web interface" 
echo 


