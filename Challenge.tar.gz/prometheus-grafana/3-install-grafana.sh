#!/bin/bash
#echo 'deb https://packagecloud.io/grafana/stable/debian/ jessie main' >> /etc/apt/sources.list
echo 'deb https://packages.grafana.com/oss/deb stable main jessie main' >> /etc/apt/sources.list.d/grafana.list
#curl https://packagecloud.io/gpg.key | sudo apt-key add -
curl https://packages.grafana.com/gpg.key | sudo apt-key add -

sudo apt-get update
sudo apt-get -y install grafana --allow-unauthenticated

sudo systemctl daemon-reload
sudo systemctl start grafana-server
sudo systemctl enable grafana-server.service
